package com.example.demo.Enum;

public enum UserEnum {
    CUSTOMER,
    ADMIN    
}
