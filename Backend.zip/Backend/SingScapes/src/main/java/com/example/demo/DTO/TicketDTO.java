package com.example.demo.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TicketDTO {
    private String type;
    private String date;
    private String price;
}
