package com.example.demo.Enum;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    FAILED
    
}
