package com.example.demo.Enum;

public enum PaymentMethod {
    VISA,
    PAYNOW,
    PAYPAL
}
