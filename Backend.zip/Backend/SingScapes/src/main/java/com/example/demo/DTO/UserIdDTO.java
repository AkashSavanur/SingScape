package com.example.demo.DTO;

import java.util.UUID;

public class UserIdDTO {
    private UUID userId;

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }
}

